const SocialNetwork = artifacts.require("SocialNetwork")

module.exports = function(deployer) {
    deployer.deploy(SocialNetwork);

};