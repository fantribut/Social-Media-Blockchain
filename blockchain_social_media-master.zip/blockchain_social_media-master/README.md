# blockchain_social_media
First studies on blockchain development using Solidity and JavaScript frameworks. For this first implementation, I'll study based on Dapp University's social network example

A Social Media based on posts that can be tipped with tokens and cryptocurrency instead of upvoted.
